/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: Roulette Project II
 * Author: Allen Gutierrez
 *
 * Created on December 5, 2017, 11:45 AM
 */

#include <iostream>
#include <fstream>
#include <string.h>
#include <iomanip>
#include <cstdlib>
#include <ctime>
#include <cmath>

using namespace std;
//Checks if user selected even number option is even
bool isEven(int num)
{
    if (num%2==0)
        return true;
    else
        return false;
}

//Odd number checker
bool isOdd(int num)
{
    if (num%2!=0)
        return true;
    else
        return false;
}

//Attempt to create loop for incorrect gametype input from user 
bool gtChk (char gt){
    if (!gt&&"N" and "n")
        return false;
    else 
        return true;
    if (!gt&&"O" and "o")
        return false;
    else 
        return true;
    if (!gt&&"E" and "e")
        return false;
    else 
        return true;
    if (!gt&&"R" and "r")
        return false; 
    else 
        return true;
    if (!gt&&"B" and "b")
        return false;
    else 
        return true;
    }

//Red number checker array size
const int red_size = 18;
//Black number checker array size
const int black_size = 18;
//Red number checker searches array of reds to see if the random # is red
bool isRed(int, int[red_size]);
//Black number checker searches array of black to see if the random # is black
bool isBlack(int, int[black_size]);

/*
 * 
 */
int main(int argc, char** argv) {

    // Constant for random number generation
    int const mnum = 1, mxnum = 36; //Minimum and maximum number values
    int num; //User inputted bet number
    int ran; //Number that ball will land on randomly via random num generator
    int strtBal; //Total balance at start
    char yn; //Choice yes or no to play game again

    
    float winnings = 0;
    float bet=winnings;

    // Use arrays for player decision
    char gt[2]; //Game type array for specific number, odd number, 
    //and even number
    int red[]={1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36}; //red # array
    int black[]={2,4,6,8,10,11,13,15,17,20,22,24,26,28,29,31,33,35};//blck # array
    int rD=0;//Red constant set to 0
    bool f=true;//Bool for REDDDDD
    int bK=0;//Black constant set to 0
    int g=true;//Bool for BLACKKKK

    // Main Menu Display Screen
cout<< "                       Welcome to Roulette.\n";
cout<<"====================================================================="
        "=====\n";

//Player inputted starting balance 
cout<<"Enter balance to play with: $"; cin >> strtBal;"\n";

begin: //Begin is here which is used if the player wants to play the game again

//Game program starts
cout<< "How much would you like to bet?: $"; cin >> bet;"\n"; //inputted bet amt

cout << "Would you like to bet on a specific number (N), an odd (O), "
        "an even (E), a red (R), or a black (B)?: ";cin >> gt; //Game type input
       
        
    // User selects a specific number to place bet on
    if(!strcmp(gt,"N")||(!strcmp(gt,"n")))//String search, checks user input
        {
        cout << "What number would you like to bet on?: ";
        cin >> num;
        srand(time(NULL));
        ran = rand() % (mxnum - mnum + 1) + mnum;

        cout << "The ball landed on " << ran << "\n";
        
    // Specific number loss
    if(num != ran)
    {
        cout << "You lose $" << bet <<endl<<"\n";
        winnings += bet;
    }
    //Specific number win
    else
    {
        cout << "You win $" << 35*bet << endl<<"\n";
        winnings -= 35*bet;
    }
    }

// User selected even number to bet on so the code will generate a random
        //even number
    if((!strcmp(gt,"E")||(!strcmp(gt,"e"))))
    {

        srand(time(NULL));
        ran = rand() % (mxnum - mnum + 1) + mnum;
        cout << "The ball landed on: " << ran << "\n";

        //Selects EVEN
        if(gt == "E"||"e")
        {
            //Even win
            if(isEven(ran))
            {
                cout << "You lost $" << bet << endl<<"\n";
                winnings -= bet;
            }
            //Even lose
            else
            {
                cout << "You win $" << bet << endl<<"\n";
                winnings += bet;
            }
        }

        
    }
    
    if((!strcmp(gt,"O")||(!strcmp(gt,"o"))))
    {

        srand(time(NULL));
        ran = rand() % (mxnum - mnum + 1) + mnum;
        cout << "The ball landed on " << ran << endl;

        //Selects Odd
        if(gt == "O"||"o")
        {
        //Odd win
            if(isOdd(ran))
            {
                cout << "You lost $" << bet << endl<<"\n";
                winnings -= bet;
            }
        //Odd lose
            else
            {
                cout << "You win $" << bet << endl<<"\n";
                winnings += bet;
            }
        } 
    }
        if((!strcmp(gt,"R")||(!strcmp(gt,"r")))) //String comparison, 
            //searches input
    {

        srand(time(NULL));
        ran = rand() % (mxnum - mnum + 1) + mnum;
        cout << "The ball landed on " << ran << endl;

        //Selects Red
        if(gt == "R"||"r")
        {
        //Red win
            if(ran==isRed(rD,red))
            {
                cout << "You win $" << bet << endl<<"\n";
                winnings += bet;
            }
        //Red lose
            else
            {
                cout << "You lose $" << bet << endl<<"\n";
                winnings -= bet;
            }
        } 
    }
         if((!strcmp(gt,"B")||(!strcmp(gt,"b"))))
    {

        srand(time(NULL));
        ran = rand() % (mxnum - mnum + 1) + mnum;
        cout << "The ball landed on " << ran << endl;

        //Selects Black
        if(gt == "B"||"b")
        {
        //Black win
            if(ran==isBlack(bK,black))
            {
                cout << "You win $" << bet << endl<<"\n";
                winnings += bet;
            }
        //Black lose
            else
            {
                cout << "You lose $" << bet << endl<<"\n";
                winnings -= bet;
            }
        } 
    }
        
        
        //Reset game if player wants to play again
        cout<<"Play again?(Y/N): "; cin>>yn; cout<<"\n";
        if ((yn == 'y')||(yn == 'Y')){
            cout<<"Your current balance is: $"<<strtBal+winnings<<endl
                    <<"\n";
            goto begin; //Takes program to begin to run through game again
        }
        
        //Displays results when player decides to stop playing
        else {
            if(winnings > bet){
        cout << "You won a total of: $" << winnings <<endl;
        cout << "Your new balance is: $ "<<strtBal+winnings;
            }
        else {
        cout << "You lost a total of: $" << winnings<<endl;
        cout << "Your new balance is: $" << strtBal-abs(winnings);
        }}
        
        //Writing results to a .txt file
        ofstream someFile ("projectIIresults.txt");
        if (someFile.is_open()){
            someFile<<"Current balance is: $ "<<strtBal+abs(winnings)<<endl;
            if(winnings < bet){
                someFile << "You lost a total of: $" << winnings<<endl;
                someFile << "Your new balance is: $ "<<strtBal-abs(winnings)
                        <<endl;
             }
            else {
                someFile << "You won a total of: $" << winnings<<endl;
                someFile << "Your new balance is: $" << strtBal+winnings<<endl;
            }
        }
        
    return 0;
}

//Red number checker 
bool isRed(int val,int array[red_size])
{
    for (int i=0;i<red_size;i++)
    {
        if (val==array[i])
            return true;
    }
            return false;
}

//Black number checker 
bool isBlack(int val,int array[black_size])
{
    for (int i=0;i<black_size;i++)
    {
        if (val==array[i])
            return true;
    }
            return false;
}
