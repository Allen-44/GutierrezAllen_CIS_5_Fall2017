/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Admin
 *
 * Created on November 3, 2017, 5:42 PM
 */

#include <iostream>     
#include <string.h>      
#include <cstdlib>        
#include <iomanip>
#include <ctime>
#include <cmath>

using namespace std;
bool isEven(int n)
{
    if (n%2==0)
        return true;
    else
        return false;
}
/*
 * 
 */
int main(int argc, char** argv) {
    // Set as CONSTANT for Random number generation
int const mnum = 1, mxnum = 36;
int num; //Number
int ran; //Random

float bet, win = 0;

// Use arrays for player decision
char gametype[2]; 
char evenodd[2];

// Main Menu Screen
cout<< "                     Welcome to Roulette.\n";
cout<<"=====================================================================\n";
cout<< "How much would you like to bet?: $"; cin >> bet;"\n";

cout << "Would you like to bet on a specific number (N) or on odd/even (O)?: "; 
cin >> gametype;

// User selects a specific number to place bet on
if(!strcmp(gametype,"n")||(!strcmp(gametype,"N")))
{
cout << "What number would you like to bet on? "
        "You can pick on a range from 0 to 36: "; 
cin >> num;
if(num == 00)
{
num = 37;
}
srand(time(NULL));
ran = rand() % (mxnum - mnum + 1) + mnum;

cout << "The ball landed on " << ran << "\n";

// Lose
if(num != ran)
{
cout << "You lose $" << bet << "\n";
win -= bet;
}
// Win
else
{
cout << "You win $" << 35*bet << endl;
win += 35*bet;
}
}

// User selects even or odd
if((!strcmp(gametype,"e"))||(!strcmp(gametype,"E"))||(!strcmp(gametype,"o"))
        ||(!strcmp(gametype,"o")))
{

cout << "Would you like to bet on even (E) or odd (O)? "; cin >> evenodd;

srand(time(NULL));
ran = rand() % (mxnum - mnum + 1) + mnum;
cout << "The ball landed on " << ran << endl;

// S.E.
if(evenodd == "e"||"E")
{
// E.W.
if(isEven(ran))             
{
cout << "You win $" << bet << endl;
win += bet;
}
// E.L.
else
{
cout << "You lose $" << bet << endl;
win -= bet;
}
}

// S.O.
else if(evenodd =="o"||"O")
{
// O.W.

{
cout << "You win $" << bet << endl;
win += bet;
}
// odd lose
else
{
cout << "You lose $" << bet << endl;
win -= bet;
}
}
}

// Final Results
if(win<bet)
{
cout << "You lost a total of $" << abs(win);
}
else
    cout<<"You won a total of $"<<win;

    return 0;
}

