/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: Roulette II
 * Author: Allen Gutierrez
 *
 * Created on November 5, 2017, 12:29 PM
 */

#include <iostream>
#include <string.h>
#include <iomanip>
#include <cstdlib>
#include <ctime>
#include <cmath>

using namespace std;
//Checks if user selected even number is even
bool isEven(int num)
{
    if (num%2==0)
        return true;
    else
        return false;
}
bool isOdd(int num)
{
    if (num%2!=0)
        return true;
    else
        return false;
}

/*
 * 
 */
int main(int argc, char** argv) {

    // Constant for random number generation
    int const mnum = 1, mxnum = 36; //Minimum and maximum number values
    int num; //User inputted bet number
    int ran; //Number that ball will land on randomly via random num generator

    float bet, winnings = 0;

    // Use arrays for player decision
    char gt[2]; //Game type array for specific number, odd number, 
    //and even number
    

    // Main Menu Display Screen
cout<< "                     Welcome to Roulette.\n";
cout<<"=====================================================================\n";
cout<< "How much would you like to bet?: $"; cin >> bet;"\n";

cout << "Would you like to bet on a specific number (N), an odd (O), "
        "or an even (E)?: ";cin >> gt; //Game type input
        
    // User selects a specific number to place bet on
    if(!strcmp(gt,"N")||(!strcmp(gt,"n")))
        {
        cout << "What number would you like to bet on?: ";
        cin >> num;
        srand(time(NULL));
        ran = rand() % (mxnum - mnum + 1) + mnum;

        cout << "The ball landed on " << ran << "\n";

    // Specific number loss
    if(num != ran)
    {
        cout << "You lose $" << bet << "\n";
        winnings -= bet;
    }
    //Specific number win
    else
    {
        cout << "You win $" << 35*bet << endl;
        winnings += 35*bet;
    }
    }

// User selected even number to bet on so the code will generate an even number
    if((!strcmp(gt,"E")||(!strcmp(gt,"e"))))
    {

        srand(time(NULL));
        ran = rand() % (mxnum - mnum + 1) + mnum;
        cout << "The ball landed on " << ran << endl;

        //Selects EVEN
        if(gt == "E"||"e")
        {
        //Even win
            if(isEven(ran))
            {
                cout << "You win $" << bet << endl;
                winnings += bet;
            }
        //Even lose
            else
            {
                cout << "You lose $" << bet << endl;
                winnings -= bet;
            }
        }

        
    }
    
    if((!strcmp(gt,"O")||(!strcmp(gt,"o"))))
    {

        srand(time(NULL));
        ran = rand() % (mxnum - mnum + 1) + mnum;
        cout << "The ball landed on " << ran << endl;

        //Selects odd
        if(gt == "O"||"o")
        {
        //Odd win
            if(isOdd(ran))
            {
                cout << "You lost $" << bet << endl;
                winnings -= bet;
            }
        //Odd lose
            else
            {
                cout << "You win $" << bet << endl;
                winnings += bet;
            }
        } 
    }

    //Final results output
    if(winnings < bet){
        cout << "You lost a total of $" << abs(winnings);
    }
    else
        cout << "You won a total of $" << winnings;
    return 0;
}

