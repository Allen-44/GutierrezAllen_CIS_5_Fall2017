/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: 4. Areas of Rectangles 
 * Author: Allen Gutierrez
 *
 * Created on October 8, 2017, 3:00 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    //Variables
    int l1, w1, l2, w2, a1, a2; //length 1, width 1, length 2, width 2, area 1, 
    //area 2
    cout<<"This program will determine which rectangle's area is larger.\n";
    //Input
    cout<<"Enter the length and width of your first rectangle: ";
    cin>>l1>>w1;
    cout<<"Enter the length and width of your second rectangle: ";
    cin>>l2>>w2;
    //Calculations
    a1=l1*w1;a2=l2*w2;
    if (a1>a2) cout<<"Rectangle 1 has a greater area.";
    else cout<<"Rectangle 2 has a greater area.";
    

    return 0;
}

