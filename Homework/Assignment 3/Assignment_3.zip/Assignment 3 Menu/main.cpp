/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: Assignment 3 Menu
 * Author: Allen Gutierrez
 *
 * Created on October 11, 2017, 11:04 AM
 */

#include <iostream>
#include <cmath>
#include <string>
#include <iomanip>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    int choice;
    cout<<"          Gaddis Chapter 4 HW Problems Menu\n";
    cout<<"----------------------------------------------------------\n";
    cout<<"1. Minimum Maximum\n";
    cout<<"2. Roman Numeral Converter\n";
    cout<<"3. Magic Dates\n";
    cout<<"4. Areas of Rectangles\n";
    cout<<"5. Body Mass Index\n";
    cout<<"6. Mass and Weight\n";
    cout<<"7. Time Calculator\n";
    cout<<"8. Color Mixer\n";
    cout<<"9. Change for a Dollar Game\n";
    cout<<"10. Math Tutor\n";
    cout<<"Which problem would you like to try?: ";
    cin>>choice;
    cout<<"-----------------------------------------------------------\n";
    
    //#1
    switch(choice) {
        case 1:
    int num1, num2; //First number, second number
    //Input
    cout<<"Enter two numbers: ";
    cin>>num1>>num2;
    //Calculations 
    if (num1 > num2) cout<<num1<<" = larger number.\n"<<num2<<" = smaller number.";
    else cout<<num2<<" = larger number.\n"<<num1<<" = smaller number.";
    }
    
    //#2 
    switch(choice) {
        case 2:
            int number;   //Input number to be converted to Roman Numeral R:1-10
    string ronum;               //Roman numeral format
    cout<<"Input a number from 1-10: ";
    cin>>number;
    
    switch(number) {
        case 11:{
            if (number>11){ronum="N/A";break;}
            else;
        }
        case 10:ronum='X'     ;break;
        case  9:ronum="IX"    ;break;
        case  8:ronum="VIII"  ;break;
        case  7:ronum="VII"   ;break;
        case  6:ronum="VI"    ;break;
        case  5:ronum="V"     ;break;
        case  4:ronum="IV"    ;break;
        case  3:ronum="III"   ;break;
        case  2:ronum="II"    ;break;
        case  1:ronum="I"     ;break;
        default:ronum="N/A";
    }
    cout<<"The number "<<number<<" in roman numeral form is: "<<ronum;
    }
    
    //#3
    switch(choice) {
        case 3:
            int m, d, y; //Month, Day, Year
    cout<<"All input should be in numeric form. Example: 6/10/60. \n";
    cout<<"Enter a month: ";
    cin>>m;
    cout<<"Enter a day: ";
    cin>>d;
    cout<<"Enter a year: ";
    cin>>y;
    cout<<"Your entered date is: "<<m<<"/"<<d<<"/"<<y<<"\n";
    if (m*d==y)cout<<"The date is magic.\n";
    else cout <<"Date isn't magic.\n";
    }
    
    //#4 
    switch(choice) {
        case 4:
    int l1, w1, l2, w2, a1, a2; //length 1, width 1, length 2, width 2, area 1, 
    //area 2
    cout<<"This program will determine which rectangle's area is larger.\n";
    //Input
    cout<<"Enter the length and width of your first rectangle: ";
    cin>>l1>>w1;
    cout<<"Enter the length and width of your second rectangle: ";
    cin>>l2>>w2;
    //Calculations
    a1=l1*w1;a2=l2*w2;
    if (a1>a2) cout<<"Rectangle 1 has a greater area.";
    else cout<<"Rectangle 2 has a greater area.";
    }
    
    //#5
    switch(choice) {
        case 5:
            float weight, height, bmi; 
    cout<<"BMI Optimal Range: 18.5 - 25\n";
    cout<<"----------------------------\n";
    //Inputs 
    cout<<"Enter your weight in lbs.: ";
    cin>>weight;
    cout<<"Enter your height in inches: ";
    cin>>height;
    cout<<"----------------------------\n";
    //Calculations
    bmi=weight*703/pow(height,2);
    cout<<setprecision(2)<<fixed;
    if (bmi>=18.5&&bmi<=25) cout<<"You have an optimal BMI of "<<bmi<<"\n";
    if (bmi<18.5) cout<<"You are underweight with a BMI of "<<bmi<<"\n";
    if (bmi>25) cout<<"You are overweight with a BMI of "<<bmi;
    }
    
    //#6
    switch(choice) {
        case 6:
            cout<<"This program will convert an inputted mass (kg) to weight (newtons).\n";
    cout<<"--------------------------------------------------------------------\n";
    int mass, weight;
    cout<<"Input a mass(kg): ";
    cin>>mass;
    cout<<"--------------------------------------------------------------------\n";
    //Conversions 
    weight=mass*9.8;
    //Arguments
    if (weight<=1000&&weight>=10) cout<<"Weight: "<<weight<<" newtons.";
    if (weight>1000) cout<<"The object is too heavy.";
    if (weight<10) cout<<"The object is too light.";
    }
    
    //#7
    switch(choice) {
        case 7: 
            int sec, min=60, hrs=3600, day=86400; //Seconds, minutes, hours, days
    cout<<"Enter a number of seconds: "; cin>>sec;
    cout<<"--------------------------------------\n";
    //Arguments
    if(sec>=86400) cout<<sec<<" seconds = "<<sec/day<<" days\n";
    
    else {if(sec>=3600){cout<<sec<<" seconds = "<<sec/hrs<<" hour\n";}
    
    else {if(sec>=60){cout<<sec<<" seconds = "<<sec/min<<" minute";}
    
    else {if(sec<60&&sec>0){cout <<sec<<" seconds = "<<sec<<" seconds\n";}
    
    else{cout << "Enter a number larger than zero.";}}}}
    }
    
    //#8
    switch(choice) {
        case 8:
             string color, color2;
    string red, blue, yellow; 
    color = "red", "blue", "yellow";
    color2 = "red", "blue", "yellow";
    
    cout<<"Color Choice: Red, Blue, Yellow.\n";
    cout<<"--------------------------------\n";
    cout<<"Enter first color: "; cin>>color;
    cout<<"Enter second color: "; cin>>color2;
    cout<<"--------------------------------\n";
    
    if(color=="red"&&color2=="blue") cout<<"You made purple!";
    else{if(color=="blue"&&color2=="red"){ cout<<"You made purple!";}
    
    if(color=="red"&&color2=="yellow") cout<<"You made orange!";
    else{if(color=="yellow"&&color2=="red"){ cout<<"You made orange!";}
    
    if(color=="blue"&&color2=="yellow") cout<<"You made green!";
    else{if(color=="yellow"&&color2=="blue"){ cout<<"You made green!";}
    
    else{cout<<"Please enter a color from the given choices and try again.";}}}}
    }
    
    //#9
    switch(choice) {
        case 9:
            cout<<"Welcome to the Change for a Dollar Game! You will enter the number or\n" 
            "combinations of pennies, nickels, dimes, and quarters "
            "required to equal 1 dollar.\n";
    cout<<"---------------------------------------------------------------------------------\n";
    
    float p, n, d, q, dlr; //penny, nickel, dime, quarter, dollar
    cout<<"Input pennies:   "; cin>>p;
    cout<<"Input nickels:   "; cin>>n;
    cout<<"Input dimes:     "; cin>>d;
    cout<<"Input quarters:  "; cin>>q;
    cout<<"----------------------------------------------------------------------------------\n";
    
    dlr=(p*.01)+(n*.05)+(d*.10)+(q*.25);
    
    if(dlr==1) cout<<"Congratulations, your input equates to $1.";
    
    else {if(dlr!=1){cout<<"Please try again.";}}
    }
    
    //#10
    switch(choice) {
        case 10:
            int x,y,z,i; //x value and y value
    unsigned seed = time(0);
    srand(seed);
    x=rand()%1000;
    y=rand()%1000;
    cout<<" "<<x<<"\n";
    cout<<"+"<<y<<"\n";
    cout<<"-----\n";
    cin>>i;
    z=x+y;
  
    if (i==z)cout<<"Congratulations!";
    else{cout<<"Sorry, that's incorrect! The answer was "<<z<<".";}
    }
   
    return 0;
}

