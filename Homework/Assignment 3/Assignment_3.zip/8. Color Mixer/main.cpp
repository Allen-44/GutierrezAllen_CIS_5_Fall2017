/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: 8. Color Mixer
 * Author: Allen Gutierrez
 *
 * Created on October 8, 2017, 6:40 PM
 */

#include <iostream>
#include <string>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
    //Variables 
    string color, color2;
    string red, blue, yellow; 
    color = "red", "blue", "yellow";
    color2 = "red", "blue", "yellow";
    
    //Input 
    cout<<"Color Choice: Red, Blue, Yellow.\n";
    cout<<"--------------------------------\n";
    cout<<"Enter first color: "; cin>>color;
    cout<<"Enter second color: "; cin>>color2;
    cout<<"--------------------------------\n";
    
    //Arguments
    if(color=="red"&&color2=="blue") cout<<"You made purple!";
    else{if(color=="blue"&&color2=="red"){ cout<<"You made purple!";}
    
    if(color=="red"&&color2=="yellow") cout<<"You made orange!";
    else{if(color=="yellow"&&color2=="red"){ cout<<"You made orange!";}
    
    if(color=="blue"&&color2=="yellow") cout<<"You made green!";
    else{if(color=="yellow"&&color2=="blue"){ cout<<"You made green!";}
    
    else{cout<<"Please enter a color from the given choices and try again.";}}}}

    return 0;
}

