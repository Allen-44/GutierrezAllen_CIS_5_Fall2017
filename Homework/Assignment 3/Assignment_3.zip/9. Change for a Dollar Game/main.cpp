/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: 9. Change for a Dollar Game
 * Author: Allen Gutierrez
 *
 * Created on October 8, 2017, 7:55 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    cout<<"Welcome to the Change for a Dollar Game! You will enter the number or\n" 
            "combinations of pennies, nickels, dimes, and quarters "
            "required to equal 1 dollar.\n";
    cout<<"---------------------------------------------------------------------------------\n";
    
    //Inputs
    float p, n, d, q, dlr; //penny, nickel, dime, quarter, dollar
    cout<<"Input pennies:   "; cin>>p;
    cout<<"Input nickels:   "; cin>>n;
    cout<<"Input dimes:     "; cin>>d;
    cout<<"Input quarters:  "; cin>>q;
    cout<<"----------------------------------------------------------------------------------\n";
    
    //Arguments and Calculations
    dlr=(p*.01)+(n*.05)+(d*.10)+(q*.25);
    
    if(dlr==1) cout<<"Congratulations, your input equates to $1.";
    
    else {if(dlr!=1){cout<<"Please try again.";}}
    
    return 0;
}

