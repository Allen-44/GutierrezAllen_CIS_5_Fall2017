/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: 5. Body Mass Index 
 * Author: Allen Gutierrez
 *
 * Created on October 8, 2017, 3:23 PM
 */

#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    //Variables
    float weight, height, bmi; 
    cout<<"BMI Optimal Range: 18.5 - 25\n";
    cout<<"----------------------------\n";
    //Inputs 
    cout<<"Enter your weight in lbs.: ";
    cin>>weight;
    cout<<"Enter your height in inches: ";
    cin>>height;
    cout<<"----------------------------\n";
    //Calculations
    bmi=weight*703/pow(height,2);
    cout<<setprecision(2)<<fixed;
    if (bmi>=18.5&&bmi<=25) cout<<"You have an optimal BMI of "<<bmi<<"\n";
    if (bmi<18.5) cout<<"You are underweight with a BMI of "<<bmi<<"\n";
    if (bmi>25) cout<<"You are overweight with a BMI of "<<bmi;

    return 0;
}

