/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: 2. Roman Numeral Converter 
 * Author: Allen Gutierrez
 *
 * Created on October 3, 2017, 11:08 AM
 */

#include <iostream>
#include<string>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
     
    int number;   //Input number to be converted to Roman Numeral R:1-10
    string ronum;               //Roman numeral format
    cout<<"Input a number from 1-10: ";
    cin>>number;
    
    switch(number) {
        case 11:{
            if (number>11){ronum="N/A";break;}
            else;
        }
        case 10:ronum='X'     ;break;
        case  9:ronum="IX"    ;break;
        case  8:ronum="VIII"  ;break;
        case  7:ronum="VII"   ;break;
        case  6:ronum="VI"    ;break;
        case  5:ronum="V"     ;break;
        case  4:ronum="IV"    ;break;
        case  3:ronum="III"   ;break;
        case  2:ronum="II"    ;break;
        case  1:ronum="I"     ;break;
        default:ronum="N/A";
    }
    cout<<"The number "<<number<<" in roman numeral form is: "<<ronum;
    return 0;
}

