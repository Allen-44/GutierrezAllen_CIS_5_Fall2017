/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: 1. Minimum Maximum 
 * Author: Allen Gutierrez
 *
 * Created on October 8, 2017, 2:18 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    //Variables
    int num1, num2; //First number, second number
    //Input
    cout<<"Enter two numbers: ";
    cin>>num1>>num2;
    //Calculations 
    if (num1 > num2) cout<<num1<<" = larger number.\n"<<num2<<" = smaller number.";
    else cout<<num2<<" = larger number.\n"<<num1<<" = smaller number.";

    return 0;
}

