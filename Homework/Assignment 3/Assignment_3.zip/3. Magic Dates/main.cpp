/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: 3. Magic Dates
 * Author: Allen Gutierrez
 *
 * Created on October 4, 2017, 5:03 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    int m, d, y; //Month, Day, Year
    cout<<"All input should be in numeric form. Example: 6/10/60. \n";
    cout<<"Enter a month: ";
    cin>>m;
    cout<<"Enter a day: ";
    cin>>d;
    cout<<"Enter a year: ";
    cin>>y;
    cout<<"Your entered date is: "<<m<<"/"<<d<<"/"<<y<<"\n";
    if (m*d==y)cout<<"The date is magic.\n";
    else cout <<"Date isn't magic.\n";
    

    return 0;
}

