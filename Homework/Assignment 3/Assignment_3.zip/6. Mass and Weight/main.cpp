/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: 6. Mass and Weight 
 * Author: Allen Gutierrez 
 *
 * Created on October 8, 2017, 4:19 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    cout<<"This program will convert an inputted mass (kg) to weight (newtons).\n";
    cout<<"--------------------------------------------------------------------\n";
    //Variable 
    int mass, weight;
    cout<<"Input a mass(kg): ";
    cin>>mass;
    cout<<"--------------------------------------------------------------------\n";
    //Conversions 
    weight=mass*9.8;
    //Arguments
    if (weight<=1000&&weight>=10) cout<<"Weight: "<<weight<<" newtons.";
    if (weight>1000) cout<<"The object is too heavy.";
    if (weight<10) cout<<"The object is too light.";
    

    return 0;
}

