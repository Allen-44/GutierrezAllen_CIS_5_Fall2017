/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: 7. Time Calculator
 * Author: Allen Gutierrez
 *
 * Created on October 8, 2017, 5:38 PM
 */

#include <iostream>
#include <iomanip>
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
    //Variables 
    int sec, min=60, hrs=3600, day=86400; //Seconds, minutes, hours, days
    
    //Input 
    cout<<"Enter a number of seconds: "; cin>>sec;
    cout<<"--------------------------------------\n";
    
    //Arguments
    if(sec>=86400) cout<<sec<<" seconds = "<<sec/day<<" days\n";
    
    else {if(sec>=3600){cout<<sec<<" seconds = "<<sec/hrs<<" hour\n";}
    
    else {if(sec>=60){cout<<sec<<" seconds = "<<sec/min<<" minute";}
    
    else {if(sec<60&&sec>0){cout <<sec<<" seconds = "<<sec<<" seconds\n";}
    
    else{cout << "Enter a number larger than zero.";}}}}
    
    return 0;
}

