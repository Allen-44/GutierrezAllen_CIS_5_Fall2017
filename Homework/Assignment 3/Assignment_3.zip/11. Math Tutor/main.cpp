/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: 11. Math Tutor
 * Author: Allen Gutierrez
 *
 * Created on October 8, 2017, 8:33 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
    //Variables
    int x,y,z,i; //x value and y value
    
    //Calculations and arguments
    unsigned seed = time(0);
    srand(seed);
    x=rand()%1000;
    y=rand()%1000;
    cout<<" "<<x<<"\n";
    cout<<"+"<<y<<"\n";
    cout<<"-----\n";
    cin>>i;
    z=x+y;
    
    //Output
    if (i==z)cout<<"Congratulations!";
    else{cout<<"Sorry, that's incorrect! The answer was "<<z<<".";}

    return 0;
}

