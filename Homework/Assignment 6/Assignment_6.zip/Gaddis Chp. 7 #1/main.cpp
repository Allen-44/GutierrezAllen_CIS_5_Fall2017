/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Admin
 *
 * Created on November 28, 2017, 10:02 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    int x[10];
    int sm = 0;
    int lrg = 0;
    int temp = 0;

    for (int i = 0; i < 10; i++)
    {
        cout << "Input number " << i+1 << ": " << endl;
        cin >> x[i];
    }

    sm = x[0];
    lrg = x[0];

    for (int i = 1; i < 10; i++)
    {
        temp = x[i];
        if (temp < sm)
            sm = temp;
        if (temp > lrg)
            lrg = temp;
    }

    cout << "Largest number is: " << lrg << endl;
    cout << "Smallest number is: " << sm << endl;
    
    return 0;
}

