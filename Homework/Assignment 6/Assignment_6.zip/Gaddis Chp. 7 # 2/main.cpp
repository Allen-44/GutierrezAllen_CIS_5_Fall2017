/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Admin
 *
 * Created on November 28, 2017, 10:40 PM
 */

#include <iostream>
#include <iomanip>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    float rF[12];
    float tot = 0;
    float avg = 0;
    float mxR = 0;
    float mnR = 0;
    float tR = 0;
    
    for (int i = 0; i < 12; i++){
        cout<<"Enter rainfall for month "<<i+1<<": "<<endl;
        cin>>rF[i];
        tot += rF[i];
    }
    
    avg = tot / 12;
    
    mxR = rF[0];
    mnR = rF[0];
    
    for (int i = 1; i <= 12; i++){
        tR = rF[i];
        if (tR < mnR)
            mnR = tR;
        if (tR > mxR)
            mxR = tR;
    }
    cout<<"Total rainfall: "<<setprecision(2)<<fixed<<showpoint<<tot<<endl;
    cout<<"Average rainfall: "<<setprecision(2)<<fixed<<showpoint<<avg<<endl;
    cout<<"Highest rainfall: "<<setprecision(2)<<fixed<<showpoint<<mxR<<endl;
    cout<<"Lowest rainfall: "<<setprecision(2)<<fixed<<showpoint<<mnR<<endl;



    return 0;
}

