/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: 5. Membership Fees Increase 
 * Author: Allen Gutierrez
 *
 * Created on October 20, 2017, 12:55 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    const float inc=.04; //Percent increase
    const int yrs=6; //Percent increase over 6 years
    float memb=2500; //Price of membership
    
    for(int i=1; i<=yrs; i++)
    {
        memb=memb+(memb*inc);
        cout<< "Year " <<i<<" fee: $" <<memb<<endl;
    }

    return 0;
}

