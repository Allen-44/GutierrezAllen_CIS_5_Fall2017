/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: 11. Population
 * Author: Allen Gutierrez
 *
 * Created on October 20, 2017, 9:00 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    float sPop=0;
    int numD=0;
    float avgI=0;
    float dPop=0;
    
    cout<<"Enter starting number of organisms: ";
    cin>>sPop;
    
    while(sPop<2)
    {
        cout<<"Starting population can't be less than 2. Try Again!!!: ";
        cin>>sPop;
    }
    
    cout<<"Enter number of days population multiplies: ";
    cin>>numD;
    
    while(numD<1)
    {
        cout<<"Number of days can't be less than 1. Try again: ";
        cin>>numD;
    }
    
    cout<<"Enter average daily increase in population (%): ";
    cin>>avgI;
    
    while(avgI<0)
    {
        cout<<"Average daily increase can't be negative. Try again: ";
        cin>>avgI;
    }
    
    for(int i=1; i<=numD; i++)
    {
        dPop=((avgI/100)*sPop)+sPop;
        cout<<"Population for day "<<i<<" is "<<dPop<<endl;
        
        sPop=dPop;
    }

    return 0;
}

