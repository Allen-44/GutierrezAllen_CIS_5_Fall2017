/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: 3. Ocean Levels
 * Author: Allen Gutierrez
 *
 * Created on October 20, 2017, 3:12 AM
 */

#include <iostream>
#include <iomanip>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    float lvl=0;
    int yrs=25;
    
    cout<<"Year"<<"           "<<"Level (mm)\n";
    for(int i=1.0; i<=yrs; i++)
    {
        lvl+=1.5;
        cout<<i<<"                "<<lvl<<"\n";
    }

    return 0;
}

