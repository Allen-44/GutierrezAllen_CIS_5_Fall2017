/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: 7. Pennies for Pay
 * Author: Allen Gutierrez
 *
 * Created on October 20, 2017, 1:45 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    int nDay=1;  //Number of days
    float m=1.0; //Money
    float tot=0; //Total
    float dP=0;  //Day pay
    
    cout<<"Enter number of days: ";cin>>nDay;
    cout<<"---------------------------------\n";
    
    while(nDay<1)
    {
        cout<<"Try again: \n";cin>>nDay;
    }
    
    for(int i=1; i<=nDay; i++)
    {
        dP=m/100;
        cout<<"Day "<<i<<" you earned $"<<dP<<"\n";
        tot+=dP;
        m*=2;
    }
    
    cout<<"---------------------------------\n";
    cout<<"Total Earnings: $"<<tot;

    return 0;
}

