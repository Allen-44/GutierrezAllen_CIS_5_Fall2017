/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: 6. Distance Traveled
 * Author: Allen Gutierrez
 *
 * Created on October 20, 2017, 1:30 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    float d; //Distance
    float s; //Speed
    int t;   //Time
    
    cout<<"Speed of the vehicle? (mph): ";cin>>s;
    
    while (s<=0)
    {
        cout<<"Speed must be greater than zero. Please re-enter: ";
        cin>>s;
    }
    
    cout<<"How many hours did it travel?: ";cin>>t;
    
    while(t<1)
    {
        cout<<"Time must be greater than zero. Please enter time again: ";
        cin>>t;
    }
    
    cout<<"\nHour\t   Dis. Traveled\n";
    cout<<"-------------------------\n";
    
    
    for(int i=1; i<=t; i++)
    {
        d=s*i;
        cout<<i<<"\t\t"<<d<<endl;
    }
    
    return 0;
}

