/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: rcc
 *
 * Created on October 17, 2017, 11:56 AM
 */

#include <iostream>
#include <cmath>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
    int yrNow=2017, yrThen;
    float infRate, prNow, prThen;
    
    
    
    cout<<"This program calculates inflation rate."<<endl;
    cout<<"Enter the year and price of the original product ";
    cout<<"as well as price today"<<endl;
    cin>>yrThen>>prThen>>prNow;
    
    
    infRate=.09;
    float delta, tol=.001,prCalc;
    float kGain=.001;
    do{
        prCalc=prThen;
        for(int year=yrThen+1;year<=yrNow;year++){
            prCalc*=(1+infRate);
        }
        delta=prNow-prCalc;
        infRate+=kGain*delta;
    }while(abs(delta)>=tol);
    
    cout<<"In "<<yrThen<<" the price = $"<<prThen<<endl;
    cout<<"In "<<yrNow<<" then price = $"<<prNow<<endl;
    cout<<"The price calculated = "<<prCalc<<endl;
    cout<<"The inflation rate = "<<infRate*100.0f<<"%"<<endl;
    
    return 0;
}

