/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: 4. Calories Burned
 * Author: Allen Gutierrez
 *
 * Created on October 20, 2017, 12:16 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    float calB; //Calories burned 
    float calPm = 3.9; //Calories per minute
    
    for(int i=10; i<=30; i+=5)
    {
        calB = i * calPm;
        cout<<"In "<<i<<" minutes you burned "<<calB<<" calories.\n";
    }

    return 0;
}

