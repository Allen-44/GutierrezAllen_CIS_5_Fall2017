/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: 9. Hotel Occupancy
 * Author: Allen Gutierrez
 *
 * Created on October 20, 2017, 7:18 PM
 */

#include <iostream>
#include <iomanip>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    int roomF=0; //Rooms on floor
    int totR=0;  //Total rooms
    int totF=0;  //Total floors
    int oRF=0;   //Occupied rooms on floor
    int totOR=0; //Total occupied rooms
    float pO=0;  //Percent occupied
    
    cout<<"Enter number of floors: ";
    cin>>totF;
    
    while(totF<1)
    {
        cout<<"Number of floors must be <= 1. Try again: ";
        cin>>totF;
    }
    
    for(int i=1; i<=totF; i++)
    {
        if(i!=13)
        {
            cout<<"Enter the number of rooms on floor "<<i<<": ";
            cin>>roomF;
            
            while(roomF<10)
            {
                cout<<"Must be at <= 10. Try again: ";
                cin>>roomF;
            }
            cout<<"Occupied rooms?: ";
            cin>>oRF;
        }
        
        totR+=roomF;
        totOR+=oRF;
    }
    
    pO=(totOR*1.0/totR)*100;
    
    cout<<"--------------------------------------------\n";
    cout<<"Hotel has a total of "<<totF<<" floors.\n";
    cout<<"Hotel has a total of "<<totR<<" rooms.\n";
    cout<<"There are "<<totOR<<" occupied rooms.\n";
    cout<<"There are "<<totR-totOR<<" available rooms.\n";
    cout<<"Percentage of occupied rooms: "<<setprecision(2)<<fixed<<pO<<"%\n";

    return 0;
}

