/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: 1. Sum of Numbers
 * Author: Allen Gutierrez
 *
 * Created on October 20, 2017, 2:13 AM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    int num = 0;
    int sum = 0;
    
    cout<<"Enter Sum Number: "; cin>>num;
    
    while(num<0)
    {
        cout<<"Positive number only please.: ";cin>>num;
    }
    
    for(int i=1; i<=num;i++)
    {
        sum+=i;
    }
    
    cout<<"Sum: "<<sum;
    
    
    return 0;
    }

