/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: 10. Average Rainfall
 * Author: Allen Gutierrez
 *
 * Created on October 20, 2017, 8:15 PM
 */

#include <iostream>
#include <iomanip>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    int numY=0;
    const int month=12;
    float totR=0;
    float rf=0;
    float avgR=0;
    
    cout<<"Enter number of years: ";cin>>numY;
    
    while(numY<1)
    {
        cout<<"Number of years must be <= 1. Try again: ";
        cin>>numY;
    }
    
    for(int i=1; i<=numY; i++)
    {
        for(int months=1; months<=month; months++)
        {
            cout<<"Please enter the rainfall for month "<<months<<": ";
            cin>>rf;
            
            while(rf<0)
            {
                cout<<"The rainfall can't be negative. Try again: ";cin>>rf;
            }
            
            totR+=rf;
        }
    }
    
    cout<<"\nNumber of months: "<<numY*month<<endl;
    cout<<"Total rainfall: "<<setprecision(2)<<fixed<<totR<<" in."<<endl;
    cout<<"Average rainfall: "<<setprecision(2)<<fixed<<totR/(numY*month)
            <<" in."<<endl;

    return 0;
}

