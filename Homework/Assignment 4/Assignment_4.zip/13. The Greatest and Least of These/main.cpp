/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: 13. The Greatest and Least of These
 * Author: Allen Gutierrez
 *
 * Created on October 20, 2017, 9:37 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    int number=0;
    int high;
    int low;
    int counter;
    
    
    
    while (number!=-99)
    {
        cout<<"Enter whole numbers. (Enter -99 to quit inputting): ";
        cin>>number;
        
        if (counter==0)
        {
            high=number;
            low=number;
        }
        else
        {
            if(number>high&&number!=-99)
                high=number;
            else if(number<low&&number!=-99)
                low=number;
        }
        counter++;

    }
    cout<<"-----------------------------------------------------------------\n";
    cout<<"Highest number entered was: "<<high<<endl;
    cout<<"Lowest number entered was:  "<<low<<endl;

    return 0;
}

