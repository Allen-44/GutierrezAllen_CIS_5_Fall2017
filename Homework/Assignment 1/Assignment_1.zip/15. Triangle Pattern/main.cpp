/*
 * File: 15. Triangle Pattern
 * Author: Allen Gutierrez
 * Created on August 31, 2017, 11:44 PM
 * Purpose: Output a triangle
 */


#include <iostream>

using namespace std;

int main(int argc, char** argv) {
    
    cout<<"   *"<<endl;
    cout<<"  ***"<<endl;
    cout<<" *****"<<endl;
    cout<<"*******"<<endl;

    return 0;
}

