/*
 * File: 17. Stock Commission
 * Author: Allen Gutierrez
 * Created on August 31, 2017, 11:44 PM
 * Purpose: Stock Purchase
 */


#include <iostream>

using namespace std;

int main(int argc, char** argv) {
    
    short nShares; //Number of shares of stock 
    float ppShare,fee;//Price per share in $/share and fee as a percent
    //SHare cost in $'s, Commission Paid in $'s, Total Paid in $'s
    float ShareCost,comPaid,totPaid;

    
    nShares=750;
    ppShare=35;
    fee=2;
    
    ShareCost=nShares*ppShare;
    comPaid=ShareCost*fee/100;//Convert percentage to decimal
    totPaid=ShareCost+comPaid;
    
    //Display/Output all pertinent variables
    cout<<"Number of shares = "<<nShares<<endl;
    cout<<"Share Price = $"<<ppShare<<"/share"<<endl;
    cout<<"Commission Fee = $"<<fee<<endl;
    cout<<"Cost of Shares = $"<<ShareCost<<endl;
    cout<<"Commission Paid = $"<<comPaid<<endl;
    cout<<"Total Paid = $"<<totPaid<<endl;
    return 0;
}

