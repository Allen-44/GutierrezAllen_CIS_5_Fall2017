/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: 2. Sales Prediction 
 * Author: Allen Gutierrez
 *
 * Created on September 16, 2017, 9:02 AM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
    //Variables
    float ct=8600000, //Company Total Sales ($)
          ets=58; //East Coast Total Sales Percentage = 58%
    
    //Unknown
    float etsd, //East Coast Total Sales in Dollars ($)
          etsp; //East Coast Total Sales Percentage
    
    //Calculations
    etsp=ets/100; //Convert EC total sales percentage to decimal
    etsd=ct*etsp; //Multiply company total by calculated decimal to come up with 58% of $8.6M
    
    //Output
    cout<<"East Coast Division Sales for this Year: "<<etsd<<"$"<<endl;
    //Comes out in scientific notation (4,988,000)

    return 0;
}

