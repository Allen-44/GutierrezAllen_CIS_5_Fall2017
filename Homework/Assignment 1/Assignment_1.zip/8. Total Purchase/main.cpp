/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: 8. Total Purchase
 * Author: Allen Gutierrez
 *
 * Created on September 16, 2017, 9:20 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    //Variables 
    float it1, //Item 1 
          it2, //Item 2
          it3, //Item 3
          it4, //Item 4
          it5, //Item 5
          st, //Sales Tax (Decimal)
          st2; //Sales Tax for Output (Percentage)
    //Unknowns
    float it1s,
          it2s,
          it3s,
          it4s,
          it5s,
          it1st,
          it2st,
          it3st,
          it4st,
          it5st;
    //Assignments
    it1=15.95, //Prices in $
    it2=24.95,
    it3=6.95,
    it4=12.95,
    it5=3.95,
    st=.07, //Sales Tax (Decimal)
    st2=7; //Sales Tax (Percentage)
    //Calculations
    it1s=it1*st;
    it2s=it2*st;
    it3s=it3*st;
    it4s=it4*st;
    it5s=it5*st;
    it1st=it1s+it1;
    it2st=it2s+it2;
    it3st=it3s+it3;
    it4st=it4s+it4;
    it5st=it5s+it5;
    //Outputs
    cout<<"Sales Tax: "<<st2<<"%"<<endl;
    cout<<"Subtotal 1: $"<<it1<<" Total w/ Tax: $"<<it1st<<endl;
    cout<<"Subtotal 2: $"<<it2<<" Total w/ Tax: $"<<it2st<<endl;
    cout<<"Subtotal 3: $"<<it3<<" Total w/ Tax: $"<<it3st<<endl;
    cout<<"Subtotal 4: $"<<it4<<" Total w/ Tax: $"<<it4st<<endl;
    cout<<"Subtotal 5: $"<<it5<<" Total w/ Tax: $"<<it5st<<endl;

    return 0;
}

