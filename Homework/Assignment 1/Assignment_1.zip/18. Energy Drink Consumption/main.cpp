/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: 18. Energy Drink Consumption
 * Author: Allen Gutierrez
 *
 * Created on September 12, 2017, 11:27 AM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
      
 
int main(int argc, char** argv) {
    
    //Variables
    
    float cust, //Number of customers surveyed
          drink, //Number that drink more than one a day
          pref_citr; //Number that prefer citrus
          
    
    //Variable Values and Calculations
    
    cust=16500,
    drink=cust*.15,
    pref_citr=drink*.58; 
    
    //Output
    
    cout<<"Customers Surveyed: "<<cust<<endl;
    
    cout<<"15% of Customers that drink more than 1 a day: "<<drink<<endl;
    cout<<"58% of those 15% that prefer citrus flavored drinks: "<<pref_citr<<endl;
    
    //The End
    
    
   

    return 0;
}

