 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: 7. Ocean Levels 
 * Author: Allen Gutierrez 
 *
 * Created on September 16, 2017, 9:48 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    //Variables 
    float csl, //Current Sea Level (mm) 
          slr; //Sea Level Rise Rate (mm)
    //Assignments
    csl=200, //In mm
    slr=1.5; //In mm
    //Unknowns 
    float slr5, //Sea Level Rise after 5 Years
          slr7, //Sea Level Rise after 7 Years
          slr10; //Sea Level Rise after 10 years
    //Calculations
    slr5=200+(slr*5),
    slr7=slr5+(slr*7),
    slr10=slr7+(slr*10);
    //Output
    cout<<"Current Sea Level: "<<csl<<" mm"<<endl;
    cout<<"Rise Rate Per Year: "<<slr<<" mm"<<endl;
    cout<<"Sea Level Rise after 5 Years: "<<slr5<<" mm"<<endl;
    cout<<"Sea Level Rise after 7 Years: "<<slr7<<" mm"<<endl;
    cout<<"Sea Level Rise after 10 Years: "<<slr10<<" mm"<<endl;
    
    
    return 0;
}

