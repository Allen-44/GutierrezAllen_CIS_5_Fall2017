/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: 6. Annual Pay  
 * Author: Allen Gutierrez
 *
 * Created on September 16, 2017, 8:01 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    //Variables
    float payAmount,
          payPeriods;
    //Assignments
    payAmount=2200, //In $
    payPeriods=26; //26 times
    //Unknowns 
    float annualPay;
    //Calculations
    annualPay=payAmount*payPeriods;
    //Output
    cout<<"Employee's Annual Pay: $"<<annualPay<<endl;
   

    return 0;
}

