/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: 3. Sales Tax 
 * Author: Allen Gutierrez
 *
 * Created on September 16, 2017, 2:58 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    //Variables
    float pur, //Purchase price
          sst, //State sales tax 
          cst; //County sales tax 
    //Variables Values 
    pur=95, //Purchase price in $
    sst=4, //State sales tax in %
    cst=2; // County sales tax %
    //Unknowns
    float tst, //Total sales tax in %
          tstd, //Total sales tax in decimal form
          stp; //Sales tax total of the purchase price
    //Calculations
    tst=sst+cst;
    tstd=tst/100;
    stp=tstd*pur;
    //OUTPUTS
    cout<<"Purchase Price: $"<<pur<<endl;
    cout<<"Total Sales Tax: "<<tst<<"%"<<endl;
    cout<<"Total Tax of Purchase: $"<<stp<<endl;
    //The End 


    return 0;
}

