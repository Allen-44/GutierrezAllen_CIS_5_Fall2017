/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: 1. Sum of Two Numbers 
 * Author: Allen Gutierrez
 *
 * Created on September 16, 2017, 7:29 AM
 */

#include <iostream>
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    //Variables 
    float vone=50, //Variable one 
          vtwo=100; //Variable Two 
    
    //Unknown Variable
    float total; //Total Variable
    
    //Calculation
    total = vone + vtwo;
    
    //Output
    cout<<"Sum of 50 and 100 = "<<total<<endl;
    
            

    return 0;
}

