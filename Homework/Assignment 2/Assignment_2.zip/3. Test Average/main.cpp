/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: 3. Test Average
 * Author: Allen Gutierrez 
 *
 * Created on September 23, 2017, 10:56 AM
 */

#include <iostream>
#include <iomanip>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    float ts1, ts2, ts3, ts4, ts5;
    float tst;
    cout<<"This program will calculate the average of test scores.\n";
    cout<<"Test score 1: ";
    cin>>ts1;
    cout<<"Test score 2: ";
    cin>>ts2;
    cout<<"Test score 3: ";
    cin>>ts3;
    cout<<"Test score 4: ";
    cin>>ts4;
    cout<<"Test score 5: ";
    cin>>ts5;
    tst=(ts1+ts2+ts3+ts4+ts5)/5;
    cout<<"Average Test Score: "<<tst;
    
    return 0;
}

