/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: 23. Stock Transaction Program
 * Author: Allen Gutierrez
 *
 * Created on September 23, 2017, 6:56 PM
 */

#include <iostream>
#include <iomanip>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    double acmes1=45.50,//Acme Software stock cost per share 1
          ns1=1000.0,//number of shares 1
          acmes2=56.90,//Acme Software stock cost per share 2
          ns2=1000.0,//number of shares 2
          sbc=.02;//Stock broker commission rate (%)
    double ast1,sbc1,ast2,sbc2,tp,asc1,asc2; //acme software total 1, 
    //acme software total 2, stock broker commission paid 1,
    //stock broker commission paid  2, total profit. (unknown variables)
    ast1=acmes1*ns1; //Total for stock when it was bought (no commission)
    sbc1=ast1*sbc; //Commission fee for stock purchase
    ast2=acmes2*ns2; //Total for stock when it was sold (no commission)
    sbc2=ast2*sbc; //Commission fee for stock selling 
    asc1=ast1-sbc1; //Total for stock when it was bought (commission applied)
    asc2=ast2-sbc2; //Total for stock when it was sold (commission applied)
    tp=asc2-asc1; //Total profit Acme Software, Inc. stock
    cout<<setprecision(2)<<fixed;
    cout<<"                Stock Portfolio\n";
    cout<<"---------------------------------------------------------\n";
    cout<<"Name: Joe Gaddis\n";
    cout<<"Company: Acme Software, Inc.\n";
    cout<<"Broker Commission Rate: 2%\n";
    cout<<"----------------------------------------------------------\n";
    cout<<"Stock Purchase Total:                $"<<ast1<<"\n";
    cout<<"Broker Commission for Purchase:      $"<<sbc1<<"\n";
    cout<<"Stock Sold Total:                    $"<<ast2<<"\n";
    cout<<"Broker Commission for Selling:       $"<<sbc2<<"\n";
    cout<<"Total Profit:                        $"<<tp<<"\n";
            
    
            
            
          
    
    return 0;
}

