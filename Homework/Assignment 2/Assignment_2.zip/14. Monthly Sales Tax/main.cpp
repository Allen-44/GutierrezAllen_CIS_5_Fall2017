/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: 14. Monthly Sales Tax
 * Author: Allen Gutierrez
 *
 * Created on September 23, 2017, 3:26 PM
 */

#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    string m; //month
    double tc,s,ssto,csto,tsto; //total collected, sales, state sales tax output,
    //county sales tax output,total sales tax output
    float sst=.04,cst=.02,tst=.06; //state sales tax(4%), county sales tax(2%), 
    //total sales tax(6%)
    cout<<"Month: ";cin>>m;
    cout<<"------------------------\n";
    cout<<"Total Collected:       $";cin>>tc;
    s=tc/1.06;ssto=s*sst;csto=s*cst;tsto=s*tst;
    cout<<setprecision(2)<<fixed;
    cout<<"Sales:                 $"<<s<<"\n";
    cout<<"County Sales Tax:      $  "<<csto<<"\n";
    cout<<"State Sales Tax:       $ "<<ssto<<"\n";
    cout<<"Total Sales Tax:       $ "<<tsto<<"\n";
    
    
            

    return 0;
}

