/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: 4. Average Rainfall
 * Author: Allen Gutierrez
 *
 * Created on September 23, 2017, 11:37 AM
 */

#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    string m1, m2, m3; //month 1, month 2, month 3
    float rf1, rf2, rf3, rfa; //rainfall 1, rainfall, 2, rainfall 3,
    //rainfall average
    cout<<"This program calculates the amount of rainfall for 3 inputted";
    cout<<"months.\n";
    //Month inputs
    cout<<"First Month: ";
    cin>>m1;
    cout<<"Second Month: ";
    cin>>m2;
    cout<<"Third Month: ";
    cin>>m3;
    //Rainfall inputs in inches
    cout<<"Amount of rain for month 1 (in inches): ";
    cin>>rf1;
    cout<<"Amount of rain for month 2 (in inches): ";
    cin>>rf2;
    cout<<"Amount of rain for month 3 (in inches): ";
    cin>>rf3;
    rfa=(rf1+rf2+rf3)/3;
    cout<<"The average rainfall for "<<m1<<", "<<m2<<", and "<<m3<<" is ";
    cout<<rfa<<" inches.";
            
    

    return 0;
}

