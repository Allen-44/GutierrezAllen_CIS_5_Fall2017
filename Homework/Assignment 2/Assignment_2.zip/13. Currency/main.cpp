/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: 13. Currency
 * Author: Allen Gutierrez
 *
 * Created on September 23, 2017, 2:27 PM
 */

#include <iostream>
#include <iomanip>

using namespace std;

/*
 * This program converts USD to Yen and Euros
 */
int main(int argc, char** argv) {
    double usd , ypd , epd;
    cout<<"This program converts USD to Yen and Euros.\n";
    cout<<"Enter amount of USD: $";
    cin>>usd;
    ypd = usd * 111.99;
    epd = usd * .84; //both Yen and Euro values up-to-date
    cout<<setprecision(2)<<fixed;
    cout<<"USD to Yen: ¥"<<ypd<<"\n";
    cout<<"USD to Euros: €"<<epd;
    
    
    
    
    
    return 0;
}

