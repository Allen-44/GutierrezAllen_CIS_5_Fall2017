/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: 17. Math Tutor
 * Author: Allen Gutierrez
 *
 * Created on September 23, 2017, 4:36 PM
 */

#include <cstdlib>
#include <iomanip>
#include <iostream>

using namespace std;

/*
 * This program will help young students with addition
 */
int main(int argc, char** argv) {
    int x,y,z,i; //x value and y value
    unsigned seed = time(0);
    srand(seed);
    x=rand()%1000;
    y=rand()%1000;
    cout<<" "<<x<<"\n";
    cout<<"+"<<y<<"\n";
    cout<<"-----\n";
    cin>>i;
    z=x+y;
    if (i==z)cout<<"Good Job!";
    else{cout<<"Try Again. The answer was "<<z;}
    //I googled the answer to this one only to see how the if and else statements
    //worked. I didn't copy and paste anything. I Observed how they added an extra
    //variable for the users input and used it to compare it to the actual answer.
    //line 32: if (i[user input]==z[calculated answer]) then it prints "Good Job"
    
            
    return 0;
}

