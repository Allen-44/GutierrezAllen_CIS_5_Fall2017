/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: 12. Celsius to Farenheit 
 * Author: Allen Gutierrez 
 *
 * Created on September 23, 2017, 1:42 PM
 */

#include <iostream>

using namespace std;

/* 
 * This program converts inputted Celsius value to Fahrenheit
 */
int main(int argc, char** argv) {
    float C; //Celsius value
    float F; //Celsius -> Fahrenheit
    cout<<"This program will convert Celsius to Fahrenheit.\n";
    cout<<"What is the Celsius temp.?: ";
    cin>>C;
    F=9.0/5*(C)+32;
    cout<<"Celsius to Fahrenheit conversion: "<<F<<endl;
    
    

    return 0;
}

