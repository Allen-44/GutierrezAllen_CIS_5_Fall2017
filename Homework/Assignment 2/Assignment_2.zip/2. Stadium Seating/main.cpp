/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: 2. Stadium Seating 
 * Author: Allen Gutierrez
 *
 * Created on September 23, 2017, 10:25 AM
 */

#include <iostream>
#include <iomanip>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    int cA, cB, cC;
    float cAp=15.00, cBp=12.00, cCp=9.00; //in $
    float cAt, cBt, cCt, gt; //in $
    cout<<"This program will calculate the amount of income generated from ";
    cout<<"seat ticket buying.\n";
    cout<<"How many tickets were purchased for Class A seating? ";
    cin>>cA;
    cout<<"How many tickets were purchased for Class B seating? ";
    cin>>cB;
    cout<<"How many tickets were purchased for Class C seating? ";
    cin>>cC;
    cAt=cA*cAp; cBt=cB*cBp; cCt=cC*cCp; gt=cAt+cBt+cCt;
    cout<<setprecision(2);
    cout<<"The amount of income generated from seat sales is: $ "<<gt;
    

    return 0;
}

