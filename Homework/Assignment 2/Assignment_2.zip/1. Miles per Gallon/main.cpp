/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Admin
 *
 * Created on September 23, 2017, 9:57 AM
 */

#include <iostream>

using namespace std;

/*
 * Program will calculate a car's gas mileage
 */
int main(int argc, char** argv) {
    int gts, nmd, mpg; //Gas tank size, number of miles it can be driven, mpg
    cout<<"This program will calculate your cars MPG.\n";
    cout<<"Enter the size of your gas tank.(gallons) ";
    cin>>gts;
    cout<<"Enter the number of miles you can drive in your car ";
    cout<<"before refueling. ";
    cin>>nmd;
    mpg=nmd/gts;
    cout<<"Your estimated MPG is: "<<mpg;
    

    return 0;
}

