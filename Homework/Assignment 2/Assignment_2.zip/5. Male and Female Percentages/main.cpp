/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File: 5. Male and Female Percentages
 * Author: Allen Gutierrez
 *
 * Created on September 23, 2017, 12:05 PM
 */

#include <iostream>

using namespace std;

/*
 * This program calculates the number of females and males in a class in 
 * percentage
 */
int main(int argc, char** argv) {
    int male, female; //Number of males and females in a class
    float ct, mp, fp; //class total, male percentage, and female percentage 
    cout<<"This program will calculate the number of females and males in a ";
    cout<<"class and convert the numbers to percentages.\n";
    cout<<"How many males are in the class?: ";
    cin>>male;
    cout<<"How many females are in the class?: ";
    cin>>female; 
    ct=male+female;
    mp=(male/ct)*100;
    fp=(female/ct)*100;
    cout<<"Class Total: "<<ct<<"\n";
    cout<<"Percentage of class that is male: "<<mp<<"%\n";
    cout<<"Percentage of class that is female: "<<fp<<"%\n";
         
    return 0;
}

